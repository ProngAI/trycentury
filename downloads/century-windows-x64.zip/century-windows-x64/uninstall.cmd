@echo off
rem uninstall.cmd: takes %LOCALAPPDATA%\Programs\Century out of your user PATH and deletes that folder.
setlocal
set "DEST=%LOCALAPPDATA%\Programs\Century"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = $env:LOCALAPPDATA + '\Programs\Century'; $p = (Get-Item 'HKCU:\Environment').GetValue('Path', '', 'DoNotExpandEnvironmentNames'); $parts = @($p -split ';' | Where-Object { $_ -ne '' -and $_ -ne $d }); New-ItemProperty -Path 'HKCU:\Environment' -Name Path -Value ($parts -join ';') -PropertyType ExpandString -Force | Out-Null; [Environment]::SetEnvironmentVariable('CENTURY_HOME', $null, 'User')"
echo Century is uninstalled: %DEST% is off your PATH and is being deleted.
if not defined CENTURY_NOPAUSE pause
cd /d "%TEMP%"
(goto) 2>nul & rmdir /s /q "%DEST%"
