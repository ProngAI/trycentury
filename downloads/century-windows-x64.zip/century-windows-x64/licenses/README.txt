The three DLLs next to century.exe are not part of Century. They are the runtime of the GCC compiler that built
century.exe, from the WinLibs build winlibs-x86_64-posix-seh-gcc-16.2.0-mingw-w64ucrt-14.0.0-r3, unmodified.

- libstdc++-6.dll and libgcc_s_seh-1.dll are from GCC. They are under the GNU General Public License version 3
  (GPL-3.0.txt) with the GCC Runtime Library Exception (GCC-RUNTIME-EXCEPTION.txt). Their source code is at
  https://gcc.gnu.org, and the WinLibs build and its sources at https://github.com/brechtsanders/winlibs_mingw/releases.
- libwinpthread-1.dll is from mingw-w64's winpthreads, under the license in winpthreads.txt. Its source code is at
  https://www.mingw-w64.org.
