@echo off
rem install.cmd: copies Century into %LOCALAPPDATA%\Programs\Century and adds that folder to your user PATH, so that
rem century works in any new terminal and the programs it builds find their three runtime DLLs. No administrator
rem rights are needed. uninstall.cmd undoes it.
setlocal
set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\Programs\Century"
if not exist "%DEST%" mkdir "%DEST%" || goto :fail
for %%f in (century.exe libgcc_s_seh-1.dll libstdc++-6.dll libwinpthread-1.dll CENTURY.md README.md hello.cy heavy.cy sumsq.cy uninstall.cmd) do (
    copy /y "%SRC%%%f" "%DEST%\" >nul || goto :fail
)
if exist "%SRC%licenses" xcopy /e /i /y /q "%SRC%licenses" "%DEST%\licenses" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = $env:LOCALAPPDATA + '\Programs\Century'; $p = (Get-Item 'HKCU:\Environment').GetValue('Path', '', 'DoNotExpandEnvironmentNames'); $parts = @($p -split ';' | Where-Object { $_ -ne '' }); if ($parts -notcontains $d) { $parts += $d; New-ItemProperty -Path 'HKCU:\Environment' -Name Path -Value ($parts -join ';') -PropertyType ExpandString -Force | Out-Null }; [Environment]::SetEnvironmentVariable('CENTURY_HOME', $d, 'User')" || goto :fail
echo.
echo Century is installed in %DEST% and that folder is on your PATH.
echo Open a new terminal (restart VS Code if you use its terminal) and run:  century --version
echo.
"%DEST%\century.exe" --version
if not defined CENTURY_NOPAUSE pause
exit /b 0
:fail
echo.
echo The installation did not finish.
if not defined CENTURY_NOPAUSE pause
exit /b 1
