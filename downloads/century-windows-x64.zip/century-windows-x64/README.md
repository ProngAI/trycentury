# Century 1.0.1 for Windows

Century's compiler for 64-bit Windows 10 and 11. `CENTURY.md`, next to this file, is the full language manual.

## Install (optional)

Double-click `install.cmd`.
- It copies Century into `%LOCALAPPDATA%\Programs\Century` and adds that folder to your user PATH. It needs no
  administrator rights.
- Then open a new terminal and run `century --version` from any folder. If you use VS Code's terminal, restart VS Code
  first.
- Programs you build anywhere then find the three runtime DLLs too.
- To remove it, run `uninstall.cmd` in that folder.

Without installing, Century runs from this folder: open a terminal here and type `.\century`, which works in both
PowerShell and cmd.

## Before you start

- The three DLLs next to `century.exe` are the runtime it needs: `libstdc++-6.dll`, `libgcc_s_seh-1.dll` and
  `libwinpthread-1.dll`. Keep them in the same folder. `licenses\README.txt` says where they come from.
- Programs you build with `--build` need the same three DLLs. Once Century is installed they find them on the PATH.
  Otherwise, build them in this folder, or copy the three DLLs next to them.
- Native code needs a CPU with AVX2, FMA and BMI2: any Intel Core from 2013 on, or any AMD Ryzen. Older CPUs run the
  interpreter.
- Century is not code-signed. If Windows says it protected your PC, choose More info, then Run anyway.

## Use

```
century --version                         # century 1.0.1 (built ..., windows-x64)
century --device                          # what your machine will run where
century hello.cy --jit main --arg 10      # jit main = 385
century hello.cy --ir-run main --arg 10   # the interpreter, every access checked
century hello.cy --build hello.exe        # a program you run as: hello.exe 10
```

Without installing, write `.\century` for `century` and `.\hello.exe` for `hello.exe`.

## The starter programs

```
century hello.cy --jit main --arg 10        # 385
century heavy.cy --jit heavy --arg 4000000  # every CPU thread
century sumsq.cy --jit sumsq --arg 1000000  # a sum with an error budget
```

`gpu do` looks for `nvcuda.dll` and `vulkan-1.dll`. With no GPU it runs on the CPU's threads instead.
