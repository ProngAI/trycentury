# Century for Windows

Century's compiler for 64-bit Windows 10 and 11. `CENTURY.md`, next to this file, is the full language manual.

## Before you start

- `century.exe` needs three runtime DLLs from MinGW-w64 on the PATH: `libstdc++-6.dll`, `libgcc_s_seh-1.dll` and
  `libwinpthread-1.dll`. Any MinGW-w64 build has them, for example WinLibs or MSYS2 (often in `C:\mingw64\bin`).
- Native code needs a CPU with AVX2, FMA and BMI2 (any Intel Core from 2013 on, any AMD Ryzen). Older CPUs run the
  interpreter.
- The program is not code-signed. If Windows says it protected your PC, choose More info, then Run anyway.

## Use

```
century --device                          # what your machine will run where
century hello.cy --jit main --arg 10      # jit main = 385
century hello.cy --ir-run main --arg 10   # the interpreter, every access checked
century hello.cy --build hello            # a standalone program, hello.exe
```

If a built program says a DLL is missing, put the same three DLLs on the PATH.

## The starter programs

```
century hello.cy --jit main --arg 10        # 385
century heavy.cy --jit heavy --arg 4000000  # every CPU thread
century sumsq.cy --jit sumsq --arg 1000000  # a sum with an error budget
```

`gpu do` looks for `nvcuda.dll` and `vulkan-1.dll`. With no GPU it runs on the CPU's threads instead.
