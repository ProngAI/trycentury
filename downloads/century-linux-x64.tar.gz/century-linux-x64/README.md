# Century for Linux

Century's compiler for Linux on x86-64. `CENTURY.md`, next to this file, is the full language manual.

## Before you start

- Needs glibc 2.38 or newer: Debian 13, Ubuntu 24.04 and later.
- Native code needs a CPU with AVX2, FMA and BMI2. Older CPUs run the interpreter.

## Use

```
./century --device                          # what your machine will run where
./century hello.cy --jit main --arg 10      # jit main = 385
./century hello.cy --ir-run main --arg 10   # the interpreter, every access checked
./century hello.cy --build hello            # a standalone program; ./hello 10 prints 385
```

## The starter programs

```
./century hello.cy --jit main --arg 10        # 385
./century heavy.cy --jit heavy --arg 4000000  # every CPU thread
./century sumsq.cy --jit sumsq --arg 1000000  # a sum with an error budget
```

## Different on Linux

- `--build` with no name makes `hello` (marked executable), not `hello.exe`.
- `extern` libraries: `extern "libc.so.6" fn getpid() -> i32`, `extern "libm.so.6" fn pow(x: f64, y: f64) -> f64`, or a
  path such as `"./libmine.so"`.
- `gpu do` looks for `libcuda.so.1` and `libvulkan.so.1`. With no GPU it runs on the CPU's threads.
