#!/bin/sh
# install.sh: copies century into ~/.local/bin and puts that folder on your PATH (in ~/.zshrc), so that century works
# in any new terminal. No administrator rights are needed. uninstall.sh undoes it.
set -e
here=$(cd "$(dirname "$0")" && pwd)
dest="$HOME/.local/bin"
mkdir -p "$dest"
cp "$here/century" "$dest/century"
chmod +x "$dest/century"
rc="$HOME/.zshrc"
line='export PATH="$HOME/.local/bin:$PATH"'
if ! grep -qsF "$line" "$rc"; then
    printf '\n# Century\n%s\n' "$line" >> "$rc"
    echo "Added ~/.local/bin to your PATH in ~/.zshrc."
fi
echo "Century is installed in $dest."
echo "Open a new terminal and run:  century --version"
"$dest/century" --version
