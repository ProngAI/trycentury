#!/bin/sh
# uninstall.sh: removes the century that install.sh put in ~/.local/bin, and the PATH line install.sh added to
# ~/.zshrc (only that one: the line after "# Century").
target="$HOME/.local/bin/century"
if [ -e "$target" ]; then
    rm -f "$target"
    echo "Removed $target."
else
    echo "Century is not installed in ~/.local/bin."
fi
rc="$HOME/.zshrc"
if grep -q '^# Century$' "$rc" 2>/dev/null; then
    sed -i '' '/^# Century$/{N;d;}' "$rc"
    echo "Removed the PATH line install.sh added to ~/.zshrc."
fi
