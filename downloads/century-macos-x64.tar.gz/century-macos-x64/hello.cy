-- hello.cy: the sum of the squares 1..n
pub fn main(n: u32) -> u64
    mut total = u64(0)
    mut i = u32(1)
    while i <= n do
        total = total + u64(i * i)
        i = i + u32(1)
    end
    return total
end
