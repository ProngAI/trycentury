-- sumsq.cy: a floating-point sum with an error budget
-- try:  century sumsq.cy --jit sumsq --arg 1000000
pub fn sumsq(n: u32) -> f64
    mut a = array[f64](n)
    mut i = u32(0)
    while i < n do
        a[i] = f64(i) * 0.001
        i = i + u32(1)
    end
    mut acc ~ 1e-6 = 0.0
    mut j = u32(0)
    while j < len(a) do
        acc = acc + a[j] * a[j]
        j = j + u32(1)
    end
    return acc
end
