# Century for macOS

Century's compiler for macOS on x86-64: natively on Intel Macs, and on Apple silicon (M1 to M4) through Rosetta 2.
`CENTURY.md`, next to this file, is the full language manual.

## Before you start

- On Apple silicon, macOS offers to install Rosetta 2 the first time an x86-64 program starts.
- If macOS blocks the program, allow it in System Settings, Privacy & Security.
- Under Rosetta, Century turns on AVX by itself (it restarts once with `ROSETTA_ADVERTISE_AVX=1`). There is nothing
  to set by hand. Programs are correct, but slower than native Apple-silicon code would be.

## Use

```
./century --device                          # what your machine will run where
./century hello.cy --jit main --arg 10      # jit main = 385
./century hello.cy --ir-run main --arg 10   # the interpreter, every access checked
./century hello.cy --build hello            # a standalone program; ./hello 10 prints 385
```

## The starter programs

```
./century hello.cy --jit main --arg 10        # 385
./century heavy.cy --jit heavy --arg 4000000  # every CPU thread
./century sumsq.cy --jit sumsq --arg 1000000  # a sum with an error budget
```

## Different on macOS

- `--build` with no name makes `hello` (marked executable), not `hello.exe`.
- `extern` libraries: `extern "/usr/lib/libSystem.B.dylib" fn getpid() -> i32`, or a path such as `"./libmine.dylib"`.
- `gpu do` uses `libvulkan.1.dylib` (the Vulkan loader over MoltenVK) when it is installed. macOS has no CUDA. With
  no GPU, `gpu do` runs on the CPU's threads.
