-- heavy.cy: a loop that runs on every CPU thread
-- try:  century heavy.cy --jit heavy --arg 4000000
-- then: CY_THREADS=1 century heavy.cy --jit heavy --arg 4000000 --jit-time
pub fn heavy(n: u32) -> f64
    mut a = array[f64](n)
    cpu do
        mut i = u32(0)
        while i < n do
            mut x = f64(i) * 0.000001
            mut k = u32(0)
            while k < u32(64) do
                x = sqrt(x * x + 1.0)
                k = k + u32(1)
            end
            a[i] = x
            i = i + u32(1)
        end
    end
    return a[n / u32(2)] + a[n - u32(1)]
end
